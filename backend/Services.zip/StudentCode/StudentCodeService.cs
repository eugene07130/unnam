using Microsoft.EntityFrameworkCore;
using UnnamHS_App_Backend.Data;   // AppDbContext 네임스페이스
using UnnamHS_App_Backend.Models;

namespace UnnamHS_App_Backend.Services;

public class StudentCodeService : IStudentCodeService
{
    private readonly AppDbContext _db;
    public StudentCodeService(AppDbContext db) => _db = db;

    public async Task<bool> IsValidAsync(string code) =>
        await _db.Students.AnyAsync(s => s.StudentCode == code && !s.IsRegistered);

    public async Task<Student?> GetByCodeAsync(string code) =>
        await _db.Students.SingleOrDefaultAsync(s => s.StudentCode == code);

    public async Task MarkAsUsedAsync(Student student)
    {
        student.IsRegistered = true;
        await _db.SaveChangesAsync();
    }
}
