using UnnamHS_App_Backend.Models;

namespace UnnamHS_App_Backend.Services;

public interface IStudentCodeService
{
    Task<bool> IsValidAsync(string code);          // 사용 가능?
    Task<Student?> GetByCodeAsync(string code);    // 코드로 Student 조회
    Task MarkAsUsedAsync(Student student);         // IsRegistered = true
}
