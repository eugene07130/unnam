namespace UnnamHS_App_Backend.Services;

public enum RegisterResult
{
    Success,
    InvalidCode,
    CodeAlreadyUsed,
    UsernameTaken
}
