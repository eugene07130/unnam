using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using UnnamHS_App_Backend.Data;  // AppDbContext
using UnnamHS_App_Backend.DTOs;
using UnnamHS_App_Backend.Models;
using UnnamHS_App_Backend.Repositories;

namespace UnnamHS_App_Backend.Services;

public class RegistrationService : IRegistrationService
{
    private readonly AppDbContext         _db;
    private readonly IUserRepository      _userRepo;
    private readonly IStudentCodeService  _codeSvc;
    private readonly IPasswordHasher<User> _hasher;

    public RegistrationService(AppDbContext db,
                               IUserRepository userRepo,
                               IStudentCodeService codeSvc,
                               IPasswordHasher<User> hasher)
    {
        _db      = db;
        _userRepo= userRepo;
        _codeSvc = codeSvc;
        _hasher  = hasher;
    }

    public async Task<RegisterResult> RegisterAsync(RegisterUserDto dto)
    {
        // 1) 학생코드 존재 여부
        var student = await _codeSvc.GetByCodeAsync(dto.StudentCode);
        if (student is null)
            return RegisterResult.InvalidCode;

        // 2) 이미 등록된 코드?
        if (student.IsRegistered)
            return RegisterResult.CodeAlreadyUsed;

        // 3) 아이디 중복?
        if (await _userRepo.UsernameExistsAsync(dto.Username))
            return RegisterResult.UsernameTaken;

        // 4) User 엔티티 생성
        var user = new User
        {
            Username     = dto.Username,
            PasswordHash = _hasher.HashPassword(null!, dto.Password),
            Role         = "student",
            StudentId    = student.Id
        };

        await _userRepo.AddAsync(user);
        student.IsRegistered = true;                 // 코드 사용 처리
        await _db.SaveChangesAsync();

        return RegisterResult.Success;
    }
}
