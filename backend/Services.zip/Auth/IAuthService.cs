using UnnamHS_App_Backend.DTOs;

namespace UnnamHS_App_Backend.Services;

public interface IAuthService
{
    /// <summary>
    /// 사용자 인증 후 JWT 포함 응답 반환. 실패 시 null.
    /// </summary>
    Task<LoginResponseDto?> AuthenticateAsync(LoginRequestDto dto);
}
