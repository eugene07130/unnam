using Microsoft.EntityFrameworkCore;
using UnnamHS_App_Backend.Data;
using UnnamHS_App_Backend.DTOs;
using UnnamHS_App_Backend.Models;
using UnnamHS_App_Backend.Repositories;

namespace UnnamHS_App_Backend.Services;

public class RegistrationService : IRegistrationService
{
    private readonly AppDbContext    _db;
    private readonly IUserRepository _users;
    private readonly IStudentVerifyService  _verify;
    private readonly IPasswordHasher<User> _hasher;

    public RegistrationService(
        AppDbContext db,
        IUserRepository users,
        IStudentVerifyService verify,
        IPasswordHasher<User> hasher)
    {
        _db = db; _users = users; _verify = verify; _hasher = hasher;
    }

    public async Task<RegisterResult> RegisterAsync(RegisterUserDto dto)
    {
        var userId = dto.UserId ?? dto.Username;  // 구 DTO 호환
        if (string.IsNullOrWhiteSpace(userId)) return RegisterResult.UsernameTaken;

        // 1) 학생코드 유효 & 미사용?
        if (!await _verify.IsUsableAsync(dto.StudentCode))
            return RegisterResult.InvalidCode; // (존재X or 이미 사용됨)

        // 2) 사용자 아이디 중복?
        if (await _users.ExistsAsync(userId))
            return RegisterResult.UsernameTaken;

        // 3) 사용자 생성 (StudentCode 문자열 FK 연결)
        var user = new User
        {
            Id           = userId,
            Name         = dto.Name,
            Role         = "student",
            StudentCode  = dto.StudentCode,
            PasswordHash = _hasher.HashPassword(null!, dto.Password),
        };

        // 4) 저장 (UNIQUE(StudentCode)로 경쟁 조건 방지)
        await _users.AddAsync(user);
        try
        {
            await _users.SaveChangesAsync();
        }
        catch (DbUpdateException)
        {
            // 경쟁 상황에서 StudentCode UNIQUE 충돌 시
            return RegisterResult.CodeAlreadyUsed;
        }

        return RegisterResult.Success;
    }
}
